'''from django.urls import path

from jobposting import views

urlpatterns = [
    path('',views.JobListView.as_view() , name='listalljobs'),
    path('<int:pk>/', views.JobDetailView.as_view(), name='detailofjob'),
    path('addnewjob/',views.JobCreateView.as_view(), name='addnewjob'),
    path('updatejob/<int:pk>/',views.JobUpdateView.as_view(), name='modifyjob'),
    path('deletejob/<int:pk>/',views.JobDeleteView.as_view(), name='deletejob'),
]'''