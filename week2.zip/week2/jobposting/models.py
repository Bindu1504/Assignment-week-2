'''from django.db import models

# Create your models here.

class JobPosting(models.Model):
    title = models.CharField(max_length=100)
    company = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
    salary = models.IntegerField()
    description = models.TextField()
'''




#title, company, location, salary, and description.

