
'''from django.urls import reverse_lazy


from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView

from jobposting.models import JobPosting


# Create your views here.

class JobListView(ListView):
    model = JobPosting
    template_name = 'jobposting/listalljobs.html'
    context_object_name = 'jobposting'

class JobDetailView(DetailView):
    model = JobPosting
    template_name = 'jobposting/detailsofjob.html'
    context_object_name = 'jobposting'
    success_url = reverse_lazy('listalljobs')

class JobCreateView(CreateView):
    model = JobPosting
    template_name = 'jobposting/addnewjob.html'
    fields='__all__'
    context_object_name = 'jobposting'
    success_url = reverse_lazy('listalljobs')

class JobUpdateView(UpdateView):
    model = JobPosting
    template_name = 'jobposting/modifyjob.html'
    fields = '__all__'
    #context_object_name = 'course'
    success_url = reverse_lazy('listalljobs')

class JobDeleteView(DeleteView):
    model = JobPosting
    template_name = 'jobposting/deletejob.html'
    fields = '__all__'
   # context_object_name = 'course'
    success_url = reverse_lazy('listalljobs')

'''