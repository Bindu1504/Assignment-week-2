

'''
from django.urls import reverse_lazy
from django.views import generic


from Ecomm.models import Product


# Create your views here.
class ProductListView(generic.ListView):
    model= Product
    template_name = 'listallprod.html'
    context_object_name = 'products'

class ProductDetailView(generic.DetailView):
    model = Product
    template_name = 'detailofselecprod.html'
    context_object_name = 'product'
    fields = ['title', 'brand', 'category', 'price']
    success_url = reverse_lazy('listallprod')

class ProductUpdateView(generic.UpdateView):
    model = Product
    template_name = 'updateprod.html'
    context_object_name = 'product'
    fields = ['title', 'brand', 'category', 'price']
    success_url = reverse_lazy('listallprod')


class ProductDeleteView(generic.DeleteView):
    model = Product
    template_name = 'removeprod.html'
    context_object_name = 'product'
    fields = ['title', 'brand', 'category', 'price']
    success_url = reverse_lazy('listallprod')

class ProductCreateView(generic.CreateView):
    model = Product
    template_name = 'addnewprod.html'
    fields = ['title', 'brand', 'category', 'price']
    context_object_name = 'product'
    success_url = reverse_lazy('listallprod')




'''