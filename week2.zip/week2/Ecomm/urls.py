'''from django.urls import path
from Ecomm import views
urlpatterns = [
    path('', views.ProductListView.as_view(), name='listallprod'),
    path('<int:pk>/', views.ProductDetailView.as_view(), name='detailofselecprod'),
    path('addnewprod/',views.ProductCreateView.as_view(), name='addnewprod'),
    path('updateprod/<int:pk>/',views.ProductUpdateView.as_view(), name='updateprod'),
    path('deleteprod/<int:pk>/',views.ProductDeleteView.as_view(), name='removeprod'),
]'''