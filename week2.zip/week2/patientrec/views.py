

# Create your views here.
from django.urls import reverse_lazy


from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView


from patientrec.models import Patient


# Create your views here.

class PatientListView(ListView):
    model = Patient
    template_name = 'patientrec/listallpatients.html'
    context_object_name = 'patients'

class PatientDetailView(DetailView):
    model = Patient
    template_name = 'patientrec/detailofpatient.html'
    context_object_name = 'patient'
    success_url = reverse_lazy('listallpatients')

class PatientCreateView(CreateView):
    model = Patient
    template_name = 'patientrec/addnewpatient.html'
    fields='__all__'
    context_object_name = 'patient'
    success_url = reverse_lazy('listallpatients')

class PatientUpdateView(UpdateView):
    model = Patient
    template_name = 'patientrec/updatepatient.html'
    fields = '__all__'
    #context_object_name = 'course'
    success_url = reverse_lazy('listallpatients')

class PatientDeleteView(DeleteView):
    model = Patient
    template_name = 'patientrec/removepatient.html'
    fields = '__all__'
   # context_object_name = 'course'
    success_url = reverse_lazy('listallpatients')

