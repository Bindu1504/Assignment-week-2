from django.apps import AppConfig


class PatientrecConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'patientrec'
