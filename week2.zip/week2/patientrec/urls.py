from django.urls import path

from patientrec import views

urlpatterns = [
    path('',views.PatientListView.as_view() , name='listallpatients'),
    path('<int:pk>/', views.PatientDetailView.as_view(), name='detailofpatient'),
    path('addnewjob/',views.PatientCreateView.as_view(), name='addnewpatient'),
    path('updatejob/<int:pk>/',views.PatientUpdateView.as_view(), name='updatepatient'),
    path('deletejob/<int:pk>/',views.PatientDeleteView.as_view(), name='removepatient'),
]