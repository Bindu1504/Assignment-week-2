'''from django.urls import path
from Educmagmt import views
urlpatterns = [
    path('',views.CourseListView.as_view() , name='listallcour'),
    path('<int:pk>/', views.CourseDetailView.as_view(), name='detailofcour'),
    path('addnewcour/',views.CourseCreateView.as_view(), name='addnewcour'),
    path('updatecour/<int:pk>/',views.CourseUpdateView.as_view(), name='updatecour'),
    path('deletecour/<int:pk>/',views.CourseDeleteView.as_view(), name='deleteoutdatedcour'),
]'''
