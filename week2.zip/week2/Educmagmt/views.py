'''from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView

from Educmagmt.models import Course


# Create your views here.

class CourseListView(ListView):
    model = Course
    template_name = 'educmgmt/listallcour.html'
    context_object_name = 'courses'

class CourseDetailView(DetailView):
    model = Course
    template_name = 'educmgmt/detailofcour.html'
    context_object_name = 'course'

class CourseCreateView(CreateView):
    model = Course
    template_name = 'educmgmt/addnewcour.html'
    fields = '__all__'
   # context_object_name = 'course'
    success_url = reverse_lazy('listallcour')

class CourseUpdateView(UpdateView):
    model = Course
    template_name = 'educmgmt/updatecour.html'
    fields = '__all__'
    #context_object_name = 'course'
    success_url = reverse_lazy('listallcour')

class CourseDeleteView(DeleteView):
    model = Course
    template_name = 'educmgmt/deleteoutdatedcour.html'
    fields = '__all__'
   # context_object_name = 'course'
    success_url = reverse_lazy('listallcour')

'''