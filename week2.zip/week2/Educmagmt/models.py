'''from django.db import models

# Create your models here.

class Course(models.Model):
    title = models.CharField(max_length=200, null=False)
    description = models.CharField(max_length=100, null=False)
    instructor_name = models.CharField(max_length=200, null=False)
    duration = models.DurationField(null=True, blank=True)
'''


# Create your models here.
#title, description, instructor name, and duration